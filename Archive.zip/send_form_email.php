<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './PHPMailer/src/Exception.php';
require './PHPMailer/src/PHPMailer.php';
require './PHPMailer/src/SMTP.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    // Create a new PHPMailer instance for sending inquiry email
    $mail = new PHPMailer();

    // SMTP configuration (if required)
    $mail->isSMTP();
    $mail->Host = 'smtp.hostinger.com';
    $mail->SMTPAuth = true;
    $mail->SMTPDebug = 3;
    $mail->Username = 'donotreply@diagnosticsfocus.com';
    $mail->Password = 'Wasim@123';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;

    // Set email parameters for inquiry email
    $mail->setFrom('donotreply@diagnosticsfocus.com', 'Diagnostics Focus');
    $mail->addAddress('drkarthikhegde@gmail.com'); // Add recipient
    $mail->Subject = 'New Inquiry Received';
    $mail->isHTML(true);
    $mail->Body = "<h2>New Inquiry Received</h2><br>Name: $name<br>Email: $email<br>Phone: $phone";

    // Send the inquiry email
    if ($mail->send()) {
        // Redirect to thankyou page
        header('Location: thankyou.html');
        exit();
    } else {
        echo 'Inquiry Email Error: ' . $mail->ErrorInfo;
    }
}
?>
